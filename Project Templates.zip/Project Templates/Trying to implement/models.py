from django.db import models


class Tv(models.Model):
    id = models.IntegerField(primary_key=True)
    ip_address = models.URLField(max_length=200)
    updated = models.DateTimeField(auto_now=True)
    description = models.TextField(max_length=200, default='')

    def __str__(self):
        return "TV%s: %s" % (self.id, self.ip_address)


class Slide(models.Model):
    index = models.IntegerField(default=0)
    tv = models.ForeignKey(Tv, on_delete=models.CASCADE, related_name='slides')
    url = models.URLField(max_length=200)
    duration = models.IntegerField(default=0)

    def save(self, *args, **kwargs):
        self.tv.save()
        super(Slide, self).save(*args, **kwargs)

    def __str__(self):
        return "[index=%s, tv=%s, url=%s, duration=%s]" % (self.index, self.tv.id,
                                                           self.url, self.duration)

    class Meta:
        ordering = ['index']
        unique_together = (("index", "tv"))


    class professor(models.Model):
        Professortitle = models.CharField(max_length=50)
        Fullname = models.CharField(max_length=30)
        phoneNum = models.CharField(max_length=20)
        email = models.CharFeidl(max_length=128)
        roomNum = models.IntegerField(max_length=6)
        par1 = models.TextField(max_length=475)
        par2 = models.TextField(max_length=475)
        par3 = models.TextField(max_length=475)
        Profimg = models.URLField(max_length=475)
        bottomImg1 = models.URLField(max_length=475)
        bottomImg2 = models.URLField(max_length=475)
        bottomImg3 = models.URLField(max_length=475)
        header = models.CharacterField(max_length=30)
    class event(models.Model):
        title = models.CharField(max_length=45)
        par1 = models.TextField(max_length=442)
        par2 = models.TextField(max_length=442)
        where = models.Character(max_length=30)
        time = models.Character(max_length=15)
        date = models.Character(max_length=20)
        Fullname = models.CharField(max_length=30)
        phoneNum = models.CharField(max_length=20)
        email = models.CharFeidl(max_length=128)
        roomNum = models.IntegerField(max_length=6)
        topImg = models.URLField(max_length=475)
        topImg2 = models.URLField(max_length=475)
        topImg3 = models.URLField(max_length=475)
        topImg4 = models.URLField(max_length=475)